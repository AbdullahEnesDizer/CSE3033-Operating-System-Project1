#! /bin/bash
if [ ! -f $1 ] #check the entered txt file 
then
echo -n"" > $1 #Checks the entered txt file, if it is not exist create it
echo -e "$1 not exists. Do you want it to be modified? (y/n): \c"
read answer
if [ $answer == "y" ]
then 
echo "A random story is created and stored in $1"
g1=$(shuf -n 1 giris.txt) #take random line from giris.txt
while [ ${#g1} == 0 ] #Checks the length of the g1 file
do
g1=$(shuf -n 1 giris.txt)
done
echo $g1 >> $1 #print 1 line from g1 in entered txt file
echo " " >> $1
g2=$(shuf -n 1 gelisme.txt) #take random line from gelisme.txt
while [ ${#g2} == 0 ] #Checks the length of the g2 file
do
g2=$(shuf -n 1 gelisme.txt)
done
echo $g2 >> $1 #print 1 line from g2 in entered txt file
echo " " >> $1
g3=$(shuf -n 1 sonuc.txt) #take random line from sonuc.txt
while [ ${#g3} == 0 ] #Checks the length of the g3 file
do
g3=$(shuf -n 1 sonuc.txt)
done
echo $g3 >> $1 #print 1 line from g3 in entered txt file
elif [ $answer == "n" ]
then
echo "Creat is canceled."
else
echo "Please enter y or n"
fi
else
echo -e "$1 already exists. Do you want it to be modified? (y/n): \c"
read answer1
if [ $answer1 == "y" ]
then 
echo "A random story is created and stored in $1"
g1=$(shuf -n 1 giris.txt)
while [ ${#g1} == 0 ]
do
g1=$(shuf -n 1 giris.txt)
done
echo $g1 > $1
echo " " >> $1
g2=$(shuf -n 1 gelisme.txt)
while [ ${#g2} == 0 ]
do
g2=$(shuf -n 1 gelisme.txt)
done
echo $g2 >> $1
echo " " >> $1
g3=$(shuf -n 1 sonuc.txt)
while [ ${#g3} == 0 ]
do
g3=$(shuf -n 1 sonuc.txt)
done
echo $g3 >> $1
elif [ $answer1 == "n" ]
then
echo "Creat is canceled."
else
echo "Please enter y or n"
fi
fi