#! /bin/bash
count=0
for file in * #loop through all files in current directory
do
if [ -f $file ] #check if it is a file
then
mkdir -p writable #create writable directory
if [ -w $file ] #check if it has -w permission
then
count=$(( count+1 )) #increment by 1 for each file moved
mv $file writable #move files with -w permission
fi 
fi
done
echo "$count files moved to writable directory."