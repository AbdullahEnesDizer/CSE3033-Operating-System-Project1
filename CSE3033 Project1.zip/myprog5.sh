#! /bin/bash

if [[ -f $1 || -d $1 ]] #checks file or directory
then
	for file in $1 #take all file
	do
		if [ -f $file ] #checks file
		then
			echo -e "Do you want to delete $file? (y/n): \c"
			read answer
			if [ $answer == "y" ] #answer yes
			then
				rm $file #remove file
				echo "1 file deleted"
				break
			else #answer no
				echo "Answer is no"
				break
			fi
		
		else #check directory
			echo -e "Do you want to delete $file? (y/n): \c"
			read answer
			if [ $answer == "y" ] #answer yes
			then
				rm -fr $file #remove directory
				echo "1 file deleted"
				break
			else #answer no
				echo "Answer is no"
				break
			fi
			
		fi
	done
else
echo "There is no any file or directory with $1"
fi